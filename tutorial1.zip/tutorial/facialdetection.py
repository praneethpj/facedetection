import cv2 as cv

img=cv.imread("dog.jpg");
graycolor=cv.cvtColor(img,cv.COLOR_BGR2GRAY)

face_cascade=cv.CascadeClassifier('haarcascade_frontalface_default.xml')

faces=face_cascade.detectMultiScale(graycolor,1.3,5)

for(x,y,w,h) in faces:
    cv.rectangle(img,(x,y),(x+w,y+h),(255,255,255),3)





cv.imshow("Sanath jayasooriya",img);
cv.waitKey(0)
cv.destroyAllWindows()



